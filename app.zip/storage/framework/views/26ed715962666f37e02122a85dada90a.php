<?php $__env->startSection('content'); ?>
    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>

            <img src="/images/profil.png" alt="">
        </div>
        <div class="dash-content">
            <div class="activity">
                <div class="title">
                    <i class="uil uil-clipboard-notes"></i>
                    <span class="text">Data Penjualan Produk</span>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="row justify-content-end mb-3">
                    <div class="col-lg-3 text-end">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah"><i
                                class="uil uil-plus"></i> Tambah Data</button>
                    </div>
                </div>

                <table id="datatable" class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Jan</th>
                            <th>Feb</th>
                            <th>Mar</th>
                            <th>Apr</th>
                            <th>Mei</th>
                            <th>Jun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->nama_produk); ?></td>
                                <td><?php echo e(number_format($item->harga_satuan)); ?></td>
                                <td><?php echo e($item->jan); ?></td>
                                <td><?php echo e($item->feb); ?></td>
                                <td><?php echo e($item->mar); ?></td>
                                <td><?php echo e($item->apr); ?></td>
                                <td><?php echo e($item->mei); ?></td>
                                <td><?php echo e($item->jun); ?></td>
                                <td class="d-flex gap-2">
                                    <!-- Tombol Edit -->
                                    <button class="btn btn-link text-primary p-0 m-0" data-bs-toggle="modal"
                                        data-bs-target="#modalEdit<?php echo e($item->id); ?>">
                                        <i class="uil uil-edit"></i>
                                    </button>

                                    <!-- Tombol Hapus -->
                                    <form action="<?php echo e(route('penjualan.destroy', $item->id)); ?>" method="POST"
                                        onsubmit="return confirm('Yakin hapus?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-link text-danger p-0 m-0"><i
                                                class="uil uil-trash-alt"></i></button>
                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center">Belum ada data penjualan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalEdit<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="modalEditLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <form action="<?php echo e(route('penjualan.update', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Data Penjualan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3"><label>Nama Produk</label>
                                <input type="text" name="nama_produk" class="form-control"
                                    value="<?php echo e($item->nama_produk); ?>" required>
                            </div>
                            <div class="mb-3"><label>Harga Satuan</label>
                                <input type="number" name="harga_satuan" class="form-control"
                                    value="<?php echo e($item->harga_satuan); ?>" required>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = ['jan', 'feb', 'mar', 'apr', 'mei', 'jun']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 mb-3">
                                        <label><?php echo e(ucfirst($bulan)); ?></label>
                                        <input type="number" name="<?php echo e($bulan); ?>" class="form-control"
                                            value="<?php echo e($item[$bulan]); ?>" required>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!-- Modal Tambah -->
    <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('penjualan.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Data Penjualan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3"><label>Nama Produk</label><input type="text" name="nama_produk"
                                class="form-control" required></div>
                        <div class="mb-3"><label>Harga Satuan</label><input type="number" name="harga_satuan"
                                class="form-control" required></div>
                        <div class="row">
                            <?php $__currentLoopData = ['jan', 'feb', 'mar', 'apr', 'mei', 'jun']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 mb-3">
                                    <label><?php echo e(ucfirst($bulan)); ?></label>
                                    <input type="number" name="<?php echo e($bulan); ?>" class="form-control" required>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary">Simpan</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(function() {
            $('#datatable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\prediksi-sembako\resources\views/admin/data-penjualan.blade.php ENDPATH**/ ?>